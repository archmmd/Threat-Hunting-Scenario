# سناریوی Threat Hunting: اجرای PowerShell از طریق Microsoft Word

`WINWORD.EXE → powershell.exe`

اگر در مصاحبه SOC T2 یا Threat Hunter با این رویداد مواجه بشم، اولین نکته‌ای که بیان می‌کنم اینه:

اجرای PowerShell از طریق Word یک رفتار مشکوک و نیازمند بررسی است، اما به‌تنهایی اثبات نمی‌کند که سیستم آلوده شده است.

هدف من اینه که مشخص کنم آیا این زنجیره حاصل فعالیت مشروع کاربر یا یک افزونه است، یا اینکه سند Office باعث اجرای کد مخرب شده و به فعالیت‌های بعدی مثل دریافت Payload، اجرای دستورات یا ارتباط با زیرساخت مهاجم منجر شده است.

## ۱. Hunt Objective & Hypothesis

هدف هانت

تعیین ماهیت اجرای PowerShell از طریق Word و بررسی فعالیت‌های مرتبط قبل و بعد از اجرای آن.

فرضیه اصلی (H1)

ممکن است یک سند Word یا محتوای مرتبط با آن باعث اجرای PowerShell برای اجرای کد، دریافت فایل یا برقراری ارتباط خارجی شده باشد.

فرضیه جایگزین (H2)

ممکن است اجرا ناشی از یک افزونه، ابزار سازمانی، اسکریپت مشروع یا فرایند خودکار تأییدشده باشد.

در شروع، فرضیه را باز نگه می‌دارم؛ هدف Threat Hunting اثبات یک حدس نیست، بلکه آزمودن آن با شواهد است.

## ۲. Telemetry & Data Sources

ابتدا اطلاعات خود رویداد را از EDR یا ابزارهایی مثل Microsoft Defender for Endpoint استخراج می‌کنم.

| داده                             | اهمیت                                              |
| -------------------------------- | -------------------------------------------------- |
| نام و مسیر پردازش والد           | تأیید می‌کند پردازش واقعاً از Word اجرا شده است    |
| `ProcessCommandLine`             | مشخص می‌کند PowerShell با چه آرگومان‌هایی اجرا شده |
| `ProcessId` و شناسه یکتای پردازش | برای ارتباط دادن رویدادها                          |
| نام میزبان و حساب کاربری         | برای تعیین محدوده بررسی                            |
| Timestamp و منطقه زمانی          | برای ساخت Timeline                                 |
| Hash و مسیر فایل اجرایی          | برای اعتبارسنجی فایل‌ها                            |
| رویدادهای شبکه و فرایندهای فرزند | برای بررسی رفتار بعدی                              |
| لاگ‌های PowerShell               | برای مشاهده جزئیات اجرای اسکریپت، در صورت ثبت شدن  |

منابع اصلی عبارت‌اند از:

- EDR / Microsoft Defender for Endpoint: پردازش‌ها، خط فرمان، رویدادهای شبکه و فعالیت‌های Endpoint
- Sysmon Event ID 1: ایجاد پردازش
- PowerShell Operational Log، Event ID 4104: محتوای Script Block، اگر ثبت آن فعال بوده باشد
- Sysmon Event ID 3: اتصال شبکه، در صورت فعال بودن این قابلیت
- Proxy، DNS و Firewall: بررسی مقصدها و ارتباطات خارجی

نکته: نبودن Event ID 4104 یا Sysmon Event ID 3 به معنی رخ ندادن رفتار نیست؛ ممکن است لاگ مربوطه ثبت نشده باشد.

## ۳. Hunt Execution & Queries

### گام اول: تأیید زنجیره والد و فرزند

اگر محیط من Microsoft Defender XDR باشد، ابتدا این Query را در Advanced Hunting اجرا می‌کنم. جدول `DeviceProcessEvents` اطلاعات مربوط به ایجاد پردازش و فیلدهای والد آن را فراهم می‌کند.&#x20;

[image](https://www.google.com/s2/favicons?domain=https://learn.microsoft.com\&sz=32)

Microsoft Learn



```
DeviceProcessEvents
| where Timestamp > ago(24h)
| where FileName in~ ("powershell.exe", "pwsh.exe")
| where InitiatingProcessFileName =~ "winword.exe"
| project
    Timestamp,
    DeviceName,
    AccountName,
    FileName,
    FolderPath,
    ProcessCommandLine,
    ProcessId,
    ProcessUniqueId,
    InitiatingProcessFileName,
    InitiatingProcessCommandLine,
    InitiatingProcessId,
    InitiatingProcessUniqueId,
    SHA1
| order by Timestamp desc
```

منطق Query:

- `Timestamp > ago(24h)` بررسی را به ۲۴ ساعت اخیر محدود می‌کند؛ بازه را با زمان رخداد تنظیم می‌کنم.
- `FileName` اجرای PowerShell را پیدا می‌کند.
- `InitiatingProcessFileName` بررسی می‌کند که پردازش آغازکننده `winword.exe` بوده باشد.
- `ProcessCommandLine` آرگومان‌های اجرای PowerShell را نشان می‌دهد.
- شناسه‌های یکتای پردازش به همبستگی دقیق‌تر رویدادها کمک می‌کنند.

محدودیت مهم: این Query فقط زنجیره مستقیم موردنظر را پیدا می‌کند. اگر Word از طریق پردازش واسطی مثل `cmd.exe`، یا یک فرایند دیگر PowerShell را اجرا کرده باشد، ممکن است این فیلتر آن را نگیرد. بنابراین بعداً Process Tree کامل را هم بررسی می‌کنم.

### گام دوم: تحلیل Command Line

در خروجی، دنبال نشانه‌هایی مثل این موارد می‌گردم:

| نشانه                                   | دلیل بررسی                                                   |
| --------------------------------------- | ------------------------------------------------------------ |
| `-EncodedCommand`                       | ممکن است محتوای دستور را از دید بررسی سریع پنهان کند         |
| `-WindowStyle Hidden`                   | ممکن است برای اجرای پنهان استفاده شود                        |
| `-NoProfile`                            | می‌تواند اجرای PowerShell را بدون بارگذاری پروفایل انجام دهد |
| `DownloadString` یا `Invoke-WebRequest` | ممکن است به دریافت محتوای خارجی اشاره کند                    |
| `IEX` یا `Invoke-Expression`            | ممکن است برای اجرای رشته به‌عنوان کد استفاده شود             |

هیچ‌کدام به‌تنهایی اثبات بدافزار نیستند. برای مثال، `-NoProfile` در اتوماسیون مشروع هم کاربرد دارد.

اگر `-EncodedCommand` وجود داشته باشد، محتوا را در محیط تحلیل ایزوله و به‌صورت آفلاین Decode می‌کنم؛ کد ناشناس را برای فهمیدن هدفش اجرا نمی‌کنم.

## ۴. Pivoting & Evidence Correlation

بعد از تحلیل خط فرمان، سه مسیر را موازی بررسی می‌کنم.

### Pivot A — ارتباطات شبکه

```
DeviceNetworkEvents
| where Timestamp > ago(24h)
| where InitiatingProcessFileName in~ ("powershell.exe", "pwsh.exe")
| where InitiatingProcessParentFileName =~ "winword.exe"
| project
    Timestamp,
    DeviceName,
    InitiatingProcessFileName,
    InitiatingProcessCommandLine,
    InitiatingProcessId,
    InitiatingProcessUniqueId,
    RemoteUrl,
    RemoteIP,
    RemotePort,
    Protocol,
    ActionType
| order by Timestamp asc
```

این Query ارتباطات شبکه ثبت‌شده‌ای را پیدا می‌کند که به PowerShell نسبت داده شده و پردازش والد آن Word گزارش شده است. فیلدهای شبکه در Defender XDR برای بررسی مقصد، پورت، پروتکل و پردازش آغازکننده مفیدند.&#x20;

[image](https://www.google.com/s2/favicons?domain=https://learn.microsoft.com\&sz=32)

Microsoft Learn



سپس بررسی می‌کنم:

- مقصد داخلی است یا خارجی؟
- دامنه و IP با سرویس‌های شناخته‌شده سازمان مطابقت دارند؟
- ارتباط قبل از اجرای PowerShell شروع شده یا پس از آن؟
- آیا چند مقصد یا ارتباط تکرارشونده وجود دارد؟
- آیا Proxy یا Firewall اطلاعات بیشتری درباره درخواست و حجم انتقال دارند؟

محدودیت: این Query فقط اتصالاتی را می‌بیند که در Telemetry موجود ثبت شده‌اند و والد مستقیم گزارش‌شده‌شان Word است. اگر شبکه از طریق پردازش دیگری مدیریت شده باشد یا والد به‌درستی در داده موجود نباشد، باید جست‌وجو را گسترده‌تر کنم. همچنین لاگ اتصال شبکه به‌تنهایی محتوای درخواست یا پاسخ HTTP را اثبات نمی‌کند.

### Pivot B — پردازش‌های فرزند PowerShell

بررسی می‌کنم که PowerShell پردازش دیگری ایجاد کرده یا نه:

```
DeviceProcessEvents
| where Timestamp > ago(24h)
| where InitiatingProcessFileName in~ ("powershell.exe", "pwsh.exe")
| project
    Timestamp,
    DeviceName,
    FileName,
    ProcessCommandLine,
    ProcessId,
    ProcessUniqueId,
    InitiatingProcessFileName,
    InitiatingProcessCommandLine,
    InitiatingProcessId,
    InitiatingProcessUniqueId
| order by Timestamp asc
```

به دنبال پردازش‌هایی مثل `cmd.exe`، ابزارهای سیستمی یا فرایندهای غیرمنتظره می‌گردم؛ اما هیچ‌کدام را صرفاً بر اساس نام مخرب تلقی نمی‌کنم.

نبودن پردازش فرزند، اجرای مخرب را رد نمی‌کند. کد ممکن است مستقیماً داخل PowerShell یا در حافظه اجرا شده باشد، بدون اینکه پردازش جدیدی ایجاد شود.

### Pivot C — فایل و آثار اجرایی

در EDR و لاگ‌های فایل بررسی می‌کنم:

- آیا فایلی در مسیرهای موقت یا پروفایل کاربر ایجاد شده؟
- آیا فایل اجرایی یا اسکریپتی دانلود شده است؟
- آیا Hash فایل با نمونه‌های دیگر یا رویدادهای سازمان ارتباط دارد؟
- آیا نشانه‌ای از Persistence یا فعالیت بعدی وجود دارد؟

هم‌زمان، اطلاعات سند Word، مسیر فایل، منشأ دریافت و فعالیت کاربر را هم بررسی می‌کنم. این کار کمک می‌کند بین یک فایل سازمانی مشروع و یک سند مشکوک تمایز بگذارم.

## ۵. Validation & Scope

در این مرحله، نتایج را اعتبارسنجی می‌کنم و بررسی را به یک رویداد منفرد محدود نمی‌کنم.

| پرسش تحلیلی                           | شواهد موردنیاز                              |
| ------------------------------------- | ------------------------------------------- |
| آیا Word واقعاً والد PowerShell بوده؟ | Process Tree و شناسه‌های پردازش             |
| آیا اجرای PowerShell مشکوک بوده؟      | خط فرمان، محتوای اسکریپت و زمینه اجرا       |
| آیا کد خارجی دریافت شده؟              | اسکریپت، لاگ شبکه یا شواهد دریافت           |
| آیا کد اجرا شده؟                      | لاگ اجرای اسکریپت یا شواهد معتبر EDR        |
| آیا میزبان دیگری درگیر بوده؟          | جست‌وجوی سراسری بر اساس رفتار، Hash و مقصد  |
| آیا داده از سیستم خارج شده؟           | شواهد انتقال، حجم، مقصد و محتوای قابل دسترس |

برای تعیین دامنه، همان الگوی رفتاری را روی سایر میزبان‌ها هم جست‌وجو می‌کنم؛ نه فقط یک IP یا Hash مشخص را.

## ۶. MITRE ATT&CK Mapping

در این مرحله فقط تکنیک‌هایی را ثبت می‌کنم که شواهد از آن‌ها پشتیبانی کنند.

| تکنیک                                | چه زمانی ثبت می‌کنم؟                                         |
| ------------------------------------ | ------------------------------------------------------------ |
| T1059.001 — PowerShell               | وقتی شواهد اجرای PowerShell را تأیید کنند                    |
| T1204.002 — Malicious File           | وقتی شواهد از اجرای فایل مخرب توسط کاربر پشتیبانی کنند       |
| T1105 — Ingress Tool Transfer        | وقتی انتقال ابزار یا محتوای مرتبط با حمله به سیستم تأیید شود |
| T1082 — System Information Discovery | وقتی فرمان‌ها یا رفتار جمع‌آوری اطلاعات سیستم تأیید شوند     |
| T1041 — Exfiltration Over C2 Channel | فقط وقتی شواهد انتقال داده از طریق کانال C2 وجود داشته باشد  |

مشاهده `WINWORD.EXE → powershell.exe` به‌تنهایی برای نسبت‌دادن همه این تکنیک‌ها کافی نیست.

## ۷. Conclusion & Confidence

در پایان، نتیجه را بر اساس شواهد موجود طبقه‌بندی می‌کنم، نه بر اساس شدت ظاهری یک رویداد.

- Suspicious: زنجیره Word → PowerShell مشاهده شده، اما رفتار مخرب هنوز اثبات نشده است.
- Malicious activity confirmed: شواهد معتبر اجرای کد یا رفتار مخرب را تأیید کرده‌اند.
- Scope undetermined: رفتار مخرب تأیید شده، اما دامنه کامل فعالیت یا اثر آن هنوز مشخص نیست.

برای همین سناریو، تا وقتی فقط اجرای PowerShell از طریق Word را می‌دانیم، نتیجه مناسب این است:

> اجرای مشکوک PowerShell از طریق Microsoft Word شناسایی شده است. بررسی خط فرمان، شواهد اجرای کد، ارتباطات شبکه و آثار روی میزبان برای تعیین ماهیت فعالیت و دامنه احتمالی آن لازم است.

این نتیجه از اعلام زودهنگام آلودگی جلوگیری می‌کند و در عین حال اهمیت رویداد را نادیده نمی‌گیرد.

## ۸. Response & Detection Improvement

اگر شواهد نشان دهند فعالیت مخرب است، بر اساس شدت و فعال بودن تهدید، اقداماتی مانند مهار میزبان، بررسی سند مبدأ، حفظ شواهد و ارجاع به Incident Response را در اولویت قرار می‌دهم.

برای Detection Engineering هم پیشنهاد می‌کنم یک Rule صرفاً روی اجرای `powershell.exe` یا وجود `-EncodedCommand` بنا نشود. بهتر است چند سیگنال با هم بررسی شوند:

- اجرای PowerShell از طریق Office
- آرگومان‌های غیرمعمول یا محتوای اسکریپت مشکوک
- ارتباط شبکه‌ای مرتبط با همان پردازش
- فایل‌های ایجادشده یا رفتارهای بعدی
- همبستگی زمانی و شناسه‌های پردازش

این رویکرد معمولاً زمینه بهتری برای تشخیص رفتار مشکوک فراهم می‌کند، در حالی که باید با فعالیت‌های مشروع سازمان هم آزمایش شود تا False Positive کنترل شود.

## پاسخ کوتاه و حرفه‌ای برای مصاحبه

اگر مصاحبه‌گر سؤال را مستقیم بپرسد و انتظار پاسخ شفاهی داشته باشد، من این‌طور جواب می‌دهم:

ابتدا اجرای PowerShell از طریق Word را به‌عنوان یک سیگنال مشکوک در نظر می‌گیرم، نه اثبات قطعی آلودگی.

در مرحله اول، Process Tree، خط فرمان، حساب کاربری، Timestamp و شناسه‌های پردازش را در EDR بررسی می‌کنم. سپس آرگومان‌های PowerShell و در صورت وجود EncodedCommand، محتوای آن را به‌صورت آفلاین تحلیل می‌کنم.

در مرحله بعد، PowerShell Logs، ارتباطات شبکه، پردازش‌های فرزند و آثار ایجاد فایل را بررسی می‌کنم تا مشخص شود آیا کد خارجی دریافت یا اجرا شده و آیا فعالیت مشکوک دیگری رخ داده است.

سپس با Pivot کردن بر اساس شناسه پردازش، مقصد شبکه، Hash و الگوی رفتاری، بررسی را به سایر میزبان‌ها گسترش می‌دهم. در نهایت، شواهد را اعتبارسنجی می‌کنم، تکنیک‌های MITRE ATT&CK را فقط در صورت وجود شواهد مناسب نسبت می‌دهم و بر اساس میزان اطمینان، درباره مهار، ارجاع به Incident Response و بهبود Detection تصمیم می‌گیرم.

نکته مهم این است که اجرای PowerShell از طریق Word به‌تنهایی اثبات بدافزار نیست؛ تصمیم نهایی باید بر اساس زنجیره شواهد گرفته شود.

این پاسخ کوتاه برای شروع جواب در مصاحبه مناسب است؛ اگر مصاحبه‌گر وارد جزئیات شود، Queryها، Pivotها و شواهد اعتبارسنجی بالا را توضیح می‌دهم.

منابع فنی برای مرور:

- [Microsoft Learn — DeviceProcessEvents](https://learn.microsoft.com/en-us/defender-xdr/advanced-hunting-deviceprocessevents-table)
- [Microsoft Learn — DeviceNetworkEvents](https://learn.microsoft.com/en-us/microsoft-365/security/defender/advanced-hunting-devicenetworkevents-table)
- [Microsoft Learn — Sysmon Events](https://learn.microsoft.com/en-us/windows/security/operating-system-security/sysmon/sysmon-events)
